# gait_analysis_full.py
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import classification_report, confusion_matrix

# 1. Load the dataset
data = pd.read_csv("gait_dataset.csv")

# 2. Basic data inspection
print("First 5 rows:\n", data.head())
print("\nDataset info:\n")
data.info()
print("\nMissing values per column:\n", data.isnull().sum())

# 3. Cleaning & Imputation
numeric_cols = data.select_dtypes(include=np.number).columns.tolist()
for col in numeric_cols:
    data[col].fillna(data[col].median(), inplace=True)

# 4. Scaling numeric features
scaler = StandardScaler()
data[numeric_cols] = scaler.fit_transform(data[numeric_cols])

# 5. Visualizations
# Bar chart: label counts
plt.figure(figsize=(6,4))
sns.countplot(x='label', data=data)
plt.title("Label Counts")
plt.savefig("bar_label_counts.png")
plt.close()


# Boxplot: speed by label
plt.figure(figsize=(6,4))
sns.boxplot(x='label', y='speed_m_s', data=data)
plt.title("Speed by Label")
plt.savefig("box_speed_by_label.png")
plt.close()

# Heatmap: correlation matrix
plt.figure(figsize=(10,8))
sns.heatmap(data[numeric_cols].corr(), annot=True, fmt=".2f", cmap="coolwarm")
plt.title("Correlation Heatmap")
plt.savefig("heatmap_correlation.png")
plt.close()

# Line chart: speed across samples
plt.figure(figsize=(8,4))
for label in data['label'].unique():
    subset = data[data['label'] == label]
    plt.plot(subset.index, subset['speed_m_s'], marker='o', linestyle='-', label=label)
plt.title("Speed Across Samples")
plt.xlabel("Sample Index")
plt.ylabel("Speed (m/s)")
plt.legend()
plt.savefig("line_speed_samples.png")
plt.close()

# Pie chart: age groups
age_bins = [0, 40, 60, 75, 100]
age_labels = ["<40", "40-59", "60-74", "75+"]
data['age_group'] = pd.cut(data['age'], bins=age_bins, labels=age_labels)
plt.figure(figsize=(6,6))
data['age_group'].value_counts().plot.pie(autopct='%1.1f%%')
plt.title("Age Group Distribution")
plt.ylabel("")
plt.savefig("pie_age_groups.png")
plt.close()

# 6. Classification with Random Forest
X = data.drop(columns=['label', 'age_group'])
y = data['label']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
clf = RandomForestClassifier(n_estimators=100, random_state=42)
clf.fit(X_train, y_train)
y_pred = clf.predict(X_test)

print("\nClassification Report:\n")
print(classification_report(y_test, y_pred))
print("Confusion Matrix:\n", confusion_matrix(y_test, y_pred))

# 7. Save cleaned CSV 
data.to_csv("gait_dataset_cleaned.csv", index=False)
print("\nCleaned dataset saved as gait_dataset_cleaned.csv")
